package com.cg.hotel.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;





import org.springframework.stereotype.Repository;

import com.cg.hotel.bean.AllHotel;
import com.cg.hotel.bean.BookHotel;


@Repository
public class IhotelImpl implements Ihotel {
	
	@PersistenceContext
	EntityManager manager;

	@Override
	public long bookHotel(BookHotel bh) {
		
		manager.persist(bh);
		
		return bh.getHotelbookid();
	}

	@Override
	public List<AllHotel> getHotels() {
		String sql= "SELECT allhotel  FROM AllHotel allhotel";
		TypedQuery<AllHotel> hotelquery =  manager.createQuery(sql,AllHotel.class);
		
		return hotelquery.getResultList();
	}

}
