package com.cg.hotel.dao;


import java.util.List;

import com.cg.hotel.bean.AllHotel;
import com.cg.hotel.bean.BookHotel;

public interface Ihotel {
	
	long bookHotel(BookHotel bh);
	List<AllHotel> getHotels();

}
