package com.cg.hotel.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="bookingdetails")
public class BookHotel {
	
	

	

		
		@Id
		@Column(name="id")
		@SequenceGenerator(name="Hotel_seq",sequenceName="seq_booking_id",allocationSize=1)
		@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="Hotel_seq")
		private int hotelbookid;
		
		@NotEmpty(message="Hotel customer name is mandatory ")
		@Pattern(regexp="[A-Z][a-z]{2,}",message=" Hotel Customer name should start with Capital letter and should contain min 3 char")
		@Column(name="customername")
		private String customerName;
		
		
		@Column(name="hotelid")
		private int hotelId;
		
	   
		
        @Column(name="noofroom")
		private int noOfRooms;
		
		
        private int amount;
		
		public BookHotel() {
			
		}

		public int getHotelbookid() {
			return hotelbookid;
		}

		public void setHotelbookid(int hotelbookid) {
			this.hotelbookid = hotelbookid;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public int getHotelId() {
			return hotelId;
		}

		public void setHotelId(int hotelId) {
			this.hotelId = hotelId;
		}

		public int getNoOfRooms() {
			return noOfRooms;
		}

		public void setNoOfRooms(int noOfRooms) {
			this.noOfRooms = noOfRooms;
		}

		public int getAmount() {
			return amount;
		}

		public void setAmount(int amount) {
			this.amount = amount;
		}

		
		
		
		

}
