package com.cg.hotel.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="hoteldetails")
public class AllHotel {
	
	@Id
	@Column(name="id")
	
	private int PhotelId;
	
	@Column(name="name")
	private String Custname;
	
	
	private String rating;
	
	private int rate;
	
	private int availablerooms;
	
	public AllHotel() {
	
	}

	public int getPhotelId() {
		return PhotelId;
	}

	public void setPhotelId(int photelId) {
		PhotelId = photelId;
	}

	public String getCustname() {
		return Custname;
	}

	public void setCustname(String custname) {
		Custname = custname;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getAvailablerooms() {
		return availablerooms;
	}

	public void setAvailablerooms(int availablerooms) {
		this.availablerooms = availablerooms;
	}

}
