package com.cg.hotel.service;

import java.util.List;

import com.cg.hotel.bean.AllHotel;
import com.cg.hotel.bean.BookHotel;

public interface IhotelService {
	
	long bookHotel(BookHotel bh);
	List<AllHotel> getHotels();

}
