package com.cg.hotel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hotel.bean.AllHotel;
import com.cg.hotel.bean.BookHotel;
import com.cg.hotel.dao.Ihotel;


@Service
@Transactional
public class IhotelServiceImpl implements IhotelService {
	@Autowired
	Ihotel ih;

	@Override
	public long bookHotel(BookHotel bh) {
		// TODO Auto-generated method stub
		return ih.bookHotel(bh);
	}

	@Override
	public List<AllHotel> getHotels() {
		// TODO Auto-generated method stub
		return ih.getHotels();
	}

}
